package org.example.Model;

import java.time.LocalDate;

import java.time.LocalDate;

public record Employee(long employeeId, String firstName, String lastName, LocalDate employmentDate, double yearlySalary, PensionPlan pensionPlan) {

}


